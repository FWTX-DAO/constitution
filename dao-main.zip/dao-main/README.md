# GnosisDAO Settings
This repo contains files describing the settings for several of the components that make up the GnosisDAO.